import{M as e}from"./chunk-89b18226.js";console.info("chrome-ext template-react-ts background script");new e("background");
//# sourceMappingURL=chunk-275e70c6.js.map
