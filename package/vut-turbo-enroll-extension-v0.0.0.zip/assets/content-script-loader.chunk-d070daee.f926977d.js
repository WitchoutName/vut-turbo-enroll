(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-d070daee.js")
    );
  })().catch(console.error);

})();
