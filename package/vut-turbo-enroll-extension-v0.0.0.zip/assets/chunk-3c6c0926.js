var c=(e=>(e.SelectedTimeblock="selectedTimeblock",e))(c||{});export{c as P};
